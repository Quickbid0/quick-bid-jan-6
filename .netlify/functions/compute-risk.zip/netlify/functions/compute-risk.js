var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/compute-risk.ts
var compute_risk_exports = {};
__export(compute_risk_exports, {
  config: () => config,
  handler: () => handler
});
module.exports = __toCommonJS(compute_risk_exports);
var config = {
  schedule: "0 * * * *"
  // every hour
};
var handler = async () => {
  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    return { statusCode: 500, body: "Missing Supabase service env" };
  }
  try {
    const since = new Date(Date.now() - 24 * 60 * 60 * 1e3).toISOString();
    const signalsResp = await fetch(
      `${SUPABASE_URL}/rest/v1/fraud_signals?created_at=gte.${since}`,
      {
        headers: {
          "apikey": SUPABASE_SERVICE_ROLE_KEY,
          "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`
        }
      }
    );
    const signals = await signalsResp.json();
    const byUser = {};
    for (const s of signals) {
      const key = s.user_id || `anon:${s.device_hash || s.ip || Math.random()}`;
      byUser[key] = byUser[key] || [];
      byUser[key].push(s);
    }
    const updates = [];
    for (const [userKey, arr] of Object.entries(byUser)) {
      let score = 0;
      const reasons = [];
      const kinds = arr.reduce((acc, x) => {
        acc[x.kind] = (acc[x.kind] || 0) + 1;
        return acc;
      }, {});
      const total = arr.length;
      if (total > 50) {
        score += 40;
        reasons.push({ rule: "velocity", total });
      } else if (total > 20) {
        score += 20;
        reasons.push({ rule: "velocity", total });
      }
      const otpResends = kinds["otp_resend"] || 0;
      if (otpResends > 5) {
        score += 20;
        reasons.push({ rule: "otp_resend", count: otpResends });
      }
      const deviceHashes = new Set(arr.map((x) => x.device_hash).filter(Boolean));
      if (deviceHashes.size === 1 && kinds["signup"] && kinds["signup"] > 2) {
        score += 25;
        reasons.push({ rule: "multi_signup_single_device", device: [...deviceHashes][0] });
      }
      const paymentFails = kinds["payment_failed"] || 0;
      if (paymentFails >= 3) {
        score += 25;
        reasons.push({ rule: "payment_failed", count: paymentFails });
      }
      const level = score >= 60 ? "high" : score >= 30 ? "medium" : "low";
      const user_id = userKey.startsWith("anon:") ? null : userKey;
      if (!user_id) continue;
      updates.push({ user_id, score, level, reasons_json: reasons });
    }
    const upsertResp = await fetch(`${SUPABASE_URL}/rest/v1/user_risk_scores`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "apikey": SUPABASE_SERVICE_ROLE_KEY,
        "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
        "Prefer": "resolution=merge-duplicates"
      },
      body: JSON.stringify(updates.map((u) => ({
        user_id: u.user_id,
        score: u.score,
        level: u.level,
        reasons_json: u.reasons_json,
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      })))
    });
    if (!upsertResp.ok) {
      const text = await upsertResp.text();
      return { statusCode: 500, body: `Failed to upsert risk scores: ${text}` };
    }
    const data = await upsertResp.json();
    return { statusCode: 200, body: JSON.stringify({ ok: true, updated: data.length }) };
  } catch (e) {
    return { statusCode: 500, body: `Error: ${e.message}` };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config,
  handler
});

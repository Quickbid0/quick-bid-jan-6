var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/risk-score-ml.ts
var risk_score_ml_exports = {};
__export(risk_score_ml_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(risk_score_ml_exports);
var handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    return { statusCode: 500, body: "Missing Supabase service env" };
  }
  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const user_id = body.user_id;
    if (!user_id) {
      return { statusCode: 400, body: "user_id is required" };
    }
    const featResp = await fetch(
      `${SUPABASE_URL}/rest/v1/vw_user_features?user_id=eq.${user_id}&select=*`,
      { headers: { "apikey": SUPABASE_SERVICE_ROLE_KEY, "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}` } }
    );
    const feats = await featResp.json();
    const f = feats?.[0] || {};
    let score = 0;
    const reasons = [];
    const otp = Number(f.otp_resend_7d || 0);
    if (otp >= 10) {
      score += 30;
      reasons.push({ feature: "otp_resend_7d", value: otp });
    } else if (otp >= 5) {
      score += 15;
      reasons.push({ feature: "otp_resend_7d", value: otp });
    }
    const pf = Number(f.payment_failed_7d || 0);
    if (pf >= 5) {
      score += 40;
      reasons.push({ feature: "payment_failed_7d", value: pf });
    } else if (pf >= 2) {
      score += 20;
      reasons.push({ feature: "payment_failed_7d", value: pf });
    }
    const devs = Number(f.distinct_devices_30d || 0);
    if (devs >= 5) {
      score += 20;
      reasons.push({ feature: "distinct_devices_30d", value: devs });
    } else if (devs >= 3) {
      score += 10;
      reasons.push({ feature: "distinct_devices_30d", value: devs });
    }
    const lf = Number(f.login_failed_7d || 0);
    if (lf >= 10) {
      score += 20;
      reasons.push({ feature: "login_failed_7d", value: lf });
    } else if (lf >= 5) {
      score += 10;
      reasons.push({ feature: "login_failed_7d", value: lf });
    }
    if (score > 100) score = 100;
    const level = score >= 70 ? "high" : score >= 40 ? "medium" : "low";
    await fetch(`${SUPABASE_URL}/rest/v1/inference_logs`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "apikey": SUPABASE_SERVICE_ROLE_KEY,
        "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
        "Prefer": "return=minimal"
      },
      body: JSON.stringify({
        user_id,
        model_id: null,
        score,
        reasons_json: reasons,
        features_json: f
      })
    });
    return { statusCode: 200, body: JSON.stringify({ user_id, score, level, reasons, features: f }) };
  } catch (e) {
    return { statusCode: 500, body: `Error: ${e.message}` };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});

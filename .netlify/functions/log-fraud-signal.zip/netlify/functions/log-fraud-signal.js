var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/log-fraud-signal.ts
var log_fraud_signal_exports = {};
__export(log_fraud_signal_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(log_fraud_signal_exports);

// netlify/functions/_utils/rateLimit.ts
var memCounters = {};
async function checkRateLimit(cfg) {
  const key = `${cfg.bucket}:${cfg.identifier}:${cfg.windowSeconds}`;
  const now = Date.now();
  const winStart = Math.floor(now / (cfg.windowSeconds * 1e3)) * cfg.windowSeconds * 1e3;
  const entry = memCounters[key];
  if (!entry || entry.windowStart !== winStart) {
    memCounters[key] = { count: 0, windowStart: winStart };
  }
  if (memCounters[key].count + 1 > cfg.limit) {
    return { allowed: false, remaining: 0 };
  }
  memCounters[key].count += 1;
  try {
    const SUPABASE_URL = process.env.SUPABASE_URL;
    const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (SUPABASE_URL && SUPABASE_SERVICE_ROLE_KEY) {
      const window_start = new Date(winStart).toISOString();
      await fetch(`${SUPABASE_URL}/rest/v1/rate_limits`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "apikey": SUPABASE_SERVICE_ROLE_KEY,
          "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
          "Prefer": "resolution=merge-duplicates"
        },
        body: JSON.stringify([{ bucket: cfg.bucket, identifier: cfg.identifier, window_start, count: 1 }])
      });
    }
  } catch {
  }
  return { allowed: true, remaining: Math.max(0, cfg.limit - memCounters[key].count) };
}

// netlify/functions/log-fraud-signal.ts
var handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  try {
    const SUPABASE_URL = process.env.SUPABASE_URL;
    const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
      return { statusCode: 500, body: "Missing Supabase service env" };
    }
    const body = event.body ? JSON.parse(event.body) : {};
    const {
      user_id,
      session_id,
      kind,
      value_json,
      ip,
      asn,
      country,
      device_hash
    } = body;
    if (!kind) {
      return { statusCode: 400, body: "kind is required" };
    }
    const xff = event.headers["x-forwarded-for"] || event.headers["x-real-ip"] || "";
    const remoteIp = (ip || String(xff).split(",")[0] || "unknown").trim();
    const ident = user_id || device_hash || remoteIp || "anon";
    const rl = await checkRateLimit({ bucket: "fraud_signal", identifier: ident, limit: 20, windowSeconds: 60 });
    if (!rl.allowed) {
      return { statusCode: 429, body: "Too Many Requests" };
    }
    const resp = await fetch(`${SUPABASE_URL}/rest/v1/fraud_signals`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "apikey": SUPABASE_SERVICE_ROLE_KEY,
        "Authorization": `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
        "Prefer": "return=representation"
      },
      body: JSON.stringify({
        user_id: user_id || null,
        session_id: session_id || null,
        kind,
        value_json: value_json || {},
        ip: ip || null,
        asn: asn || null,
        country: country || null,
        device_hash: device_hash || null
      })
    });
    if (!resp.ok) {
      const text = await resp.text();
      return { statusCode: 500, body: `Failed to insert fraud signal: ${text}` };
    }
    const data = await resp.json();
    return { statusCode: 200, body: JSON.stringify({ ok: true, data }) };
  } catch (e) {
    return { statusCode: 500, body: `Error: ${e.message}` };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});

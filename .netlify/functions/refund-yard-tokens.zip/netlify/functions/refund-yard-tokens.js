var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/refund-yard-tokens.ts
var refund_yard_tokens_exports = {};
__export(refund_yard_tokens_exports, {
  config: () => config,
  handler: () => handler
});
module.exports = __toCommonJS(refund_yard_tokens_exports);
var config = {
  schedule: "15 * * * *"
  // run at 15 minutes past every hour
};
var handler = async () => {
  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    return { statusCode: 500, body: "Missing Supabase service env" };
  }
  try {
    const tokensResp = await fetch(
      `${SUPABASE_URL}/rest/v1/yard_tokens?status=eq.held`,
      {
        headers: {
          apikey: SUPABASE_SERVICE_ROLE_KEY,
          Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`
        }
      }
    );
    if (!tokensResp.ok) {
      const text = await tokensResp.text();
      return { statusCode: 500, body: `Failed to load yard tokens: ${text}` };
    }
    const tokens = await tokensResp.json();
    if (!tokens || tokens.length === 0) {
      return { statusCode: 200, body: JSON.stringify({ ok: true, refunded: 0 }) };
    }
    const byYard = {};
    for (const t of tokens) {
      byYard[t.yard_id] = byYard[t.yard_id] || [];
      byYard[t.yard_id].push(t);
    }
    let refundCount = 0;
    for (const [yardId, yardTokens] of Object.entries(byYard)) {
      const auctionsResp = await fetch(
        `${SUPABASE_URL}/rest/v1/auctions?yard_id=eq.${encodeURIComponent(
          yardId
        )}&status=in.(ended,settled)`,
        {
          headers: {
            apikey: SUPABASE_SERVICE_ROLE_KEY,
            Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`
          }
        }
      );
      if (!auctionsResp.ok) {
        console.error(
          `Failed to load auctions for yard ${yardId}:`,
          await auctionsResp.text()
        );
        continue;
      }
      const auctions = await auctionsResp.json();
      const winnerSet = new Set(
        auctions.map((a) => a.winner_user_id).filter((u) => !!u)
      );
      const refundable = yardTokens.filter((t) => !winnerSet.has(t.user_id));
      if (refundable.length === 0) continue;
      for (const token of refundable) {
        const refundTxResp = await fetch(
          `${SUPABASE_URL}/rest/v1/wallet_transactions`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              apikey: SUPABASE_SERVICE_ROLE_KEY,
              Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
              Prefer: "return=representation"
            },
            body: JSON.stringify([
              {
                user_id: token.user_id,
                amount: token.amount,
                transaction_type: "refund",
                status: "completed",
                yard_id: yardId,
                description: "Yard token refund"
              }
            ])
          }
        );
        if (!refundTxResp.ok) {
          console.error(
            `Failed to insert refund tx for token ${token.id}:`,
            await refundTxResp.text()
          );
          continue;
        }
        const refundTxJson = await refundTxResp.json();
        const refundTxId = refundTxJson?.[0]?.id ?? null;
        const walletUpdateResp = await fetch(
          `${SUPABASE_URL}/rest/v1/rpc/update_wallet_balance`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              apikey: SUPABASE_SERVICE_ROLE_KEY,
              Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`
            },
            body: JSON.stringify({
              p_user_id: token.user_id,
              p_amount: token.amount
            })
          }
        );
        if (!walletUpdateResp.ok) {
          console.error(
            `Failed to update wallet for refund token ${token.id}:`,
            await walletUpdateResp.text()
          );
          continue;
        }
        try {
          await fetch(`${SUPABASE_URL}/rest/v1/notifications`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              apikey: SUPABASE_SERVICE_ROLE_KEY,
              Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
              Prefer: "return=minimal"
            },
            body: JSON.stringify([
              {
                user_id: token.user_id,
                type: "wallet",
                title: "Wallet refund processed",
                message: `Your yard token amount of ${token.amount} has been refunded to your wallet.`,
                metadata: {
                  yard_id: yardId,
                  yard_token_id: token.id,
                  refund_transaction_id: refundTxId
                },
                read: false,
                read_at: null
              }
            ])
          });
        } catch (notifErr) {
          console.error("refund-yard-tokens: failed to insert wallet notification", notifErr);
        }
        const updateTokenResp = await fetch(
          `${SUPABASE_URL}/rest/v1/yard_tokens?id=eq.${token.id}`,
          {
            method: "PATCH",
            headers: {
              "Content-Type": "application/json",
              apikey: SUPABASE_SERVICE_ROLE_KEY,
              Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
              Prefer: "return=minimal"
            },
            body: JSON.stringify({
              status: "refunded",
              refunded_transaction_id: refundTxId,
              updated_at: (/* @__PURE__ */ new Date()).toISOString()
            })
          }
        );
        if (!updateTokenResp.ok) {
          console.error(
            `Failed to mark yard_token ${token.id} as refunded:`,
            await updateTokenResp.text()
          );
          continue;
        }
        refundCount += 1;
      }
      const winnerTokens = yardTokens.filter((t) => winnerSet.has(t.user_id));
      if (winnerTokens.length > 0) {
        const ids = winnerTokens.map((t) => t.id).join(",");
        const forfeitedResp = await fetch(
          `${SUPABASE_URL}/rest/v1/yard_tokens?id=in.(${ids})`,
          {
            method: "PATCH",
            headers: {
              "Content-Type": "application/json",
              apikey: SUPABASE_SERVICE_ROLE_KEY,
              Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
              Prefer: "return=minimal"
            },
            body: JSON.stringify({
              status: "forfeited",
              updated_at: (/* @__PURE__ */ new Date()).toISOString()
            })
          }
        );
        if (!forfeitedResp.ok) {
          console.error(
            `Failed to mark winner yard_tokens forfeited for yard ${yardId}:`,
            await forfeitedResp.text()
          );
        }
      }
    }
    return { statusCode: 200, body: JSON.stringify({ ok: true, refunded: refundCount }) };
  } catch (e) {
    console.error("refund-yard-tokens error", e);
    return { statusCode: 500, body: `Error: ${e.message}` };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config,
  handler
});
